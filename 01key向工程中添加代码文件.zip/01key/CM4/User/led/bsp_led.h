/*
 * led.h
 *
 *  Created on: Nov 7, 2020
 *      Author: embedfire
 */

#ifndef LED_BSP_LED_H_
#define LED_BSP_LED_H_

#include "stm32mp1xx.h"
#include "main.h"

//引脚定义
/*******************************************************/
// 独立的蓝色LED
#define LED1_PIN                  BLUE_LED_Pin
#define LED1_GPIO_PORT            BLUE_LED_GPIO_Port


/************************************************************/


/** 控制LED灯亮灭的宏，
	* LED低电平亮，设置ON=0，OFF=1
	* 若LED高电平亮，把宏设置成ON=1 ，OFF=0 即可
	*/
#define ON  GPIO_PIN_RESET
#define OFF GPIO_PIN_SET

/* 带参宏，可以像内联函数一样使用 */
#define LED1(a)	 HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_PIN,a)


/* 定义控制IO的宏 */
#define LED1_TOGGLE		HAL_GPIO_TogglePin(LED1_GPIO_PORT,LED1_PIN)
#define LED1_OFF		HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_PIN,OFF)
#define LED1_ON			HAL_GPIO_WritePin(LED1_GPIO_PORT,LED1_PIN,ON)



void LED_GPIO_Config(void);


#endif /* LED_BSP_LED_H_ */
