/*
 * app_main.c
 *
 *  Created on: Nov 7, 2020
 *      Author: zhan
 */

#include "main_task.h"


void main_task(void)
{

	LED_GPIO_Config();		//初始化LED状态为灭

	while(1)
	{

		if( Key_Scan(KEY1_GPIO_PORT,KEY1_PIN) == KEY_ON )
		{
			LED1_TOGGLE;
		}

	}

}

