/*
 * app_main.h
 *
 *  Created on: Nov 7, 2020
 *      Author: zhan
 */

#ifndef MAIN_TASK_H_
#define MAIN_TASK_H_

#include "./key/bsp_key.h"
#include "./led/bsp_led.h"

//在main.c最终需要调用的函数
void main_task(void);


#endif /* MAIN_TASK_H_ */
